<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\EgiftUser */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Egift Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="egift-user-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'user_id',
            'egift_id',
            'orig_price',
            'sale_price',
            'to',
            'status',
            'updated_at',
            'created_at',
        ],
    ]) ?>

</div>
