<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = $name;
?>


<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="clearfix">
        <h1 class="float-left display-3 mr-4">404</h1>
        <h4 class="pt-3">Oops! You're lost.</h4>
        <p class="text-muted">  <?= nl2br(Html::encode($message)) ?></p>
      </div>
      <div class="input-prepend input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <i class="fa fa-search"></i>
          </span>
        </div>
        <input class="form-control" id="prependedInput" size="16" type="text" placeholder="What are you looking for?">
        <span class="input-group-append">
            <?= Html::a('Search', ['/dashboard'], ['class' => 'btn btn-info']) ?>
        </span>
      </div>
    </div>
  </div>
</div>
