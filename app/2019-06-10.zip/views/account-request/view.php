<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\AccountRequest */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Account Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="account-request-view">

    <h2><?= Html::encode($this->title) ?></h2> <hr>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'name',
            'email:email',
            'telephone_no',
            'description:ntext',
            'address:ntext',
            'status',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>
