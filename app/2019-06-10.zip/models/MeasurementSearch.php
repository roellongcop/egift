<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Measurement;
use yii\helpers\ArrayHelper;

/**
 * MeasurementSearch represents the model behind the search form of `app\models\Measurement`.
 */
class MeasurementSearch extends Measurement
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['name', 'description', 'status', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Measurement::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'user_id' => $this->user_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);


        if(Yii::$app->user->identity->user_type === 1) {
            $query->andFilterWhere(['user_id' => Yii::$app->user->identity->id]);
        }

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['like', 'description', $this->description])
            ->andFilterWhere(['like', 'status', $this->status])
            ->andFilterWhere(['<>', 'status',9]);

        return $dataProvider;
    }

    public static function dropDown()
    {
        $records = Measurement::find()
            ->where(['status' => 0, 'user_id' => Yii::$app->user->identity->id])
            ->orderBy('name', 'asc')
            ->all();

        $records = ArrayHelper::map($records, 'id' , 'name');

        return $records;
    }
}
